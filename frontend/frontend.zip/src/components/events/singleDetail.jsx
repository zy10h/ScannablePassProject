import { useState } from "react";
import { useParams } from "react-router-dom";
import { EVENTS } from "../constants";

const EventDetailPage = () => {
  const { id } = useParams();
  const event = EVENTS // TODO: replace with api call

  const [registered, setRegistered] = useState(false);

  if (!event) {
    return (
      <div className="max-w-4xl mx-auto p-8 text-center text-gray-600">
        <h2 className="text-2xl font-semibold">Event not found</h2>
      </div>
    );
  }

  return (
     <div className="max-w-6xl mx-auto p-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 bg-white rounded-2xl shadow-lg overflow-hidden">
        <div>
          <img
            src={event.image}
            alt={event.title}
            className="w-full h-96 object-cover rounded-lg"
          />
        </div>
        <div className="flex flex-col justify-between p-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{event.title}</h1>
            <p className="mt-4 text-gray-600">{event.description}</p>
            <div className="mt-6 space-y-3 text-gray-700">
              <p><span className="font-semibold">📍 Location:</span> {event.location}</p>
              <p><span className="font-semibold">📅 Date:</span> {event.date} at {event.time}</p>
              <p><span className="font-semibold">🎟 Seats:</span> {event.seatsFilled}/{event.availableSeats} booked</p>
              <p><span className="font-semibold">🏷 Category:</span> {event.category}</p>
            </div>
          </div>
          <button
            onClick={() => setRegistered(true)}
            disabled={registered}
            className={`mt-6 w-full py-3 px-4 rounded-xl text-white font-semibold transition ${
              registered
                ? "bg-gray-400 cursor-not-allowed"
                : "bg-blue-600 hover:bg-blue-700"
            }`}
          >
            {registered ? "Registered ✔" : "Register Now"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default EventDetailPage;
